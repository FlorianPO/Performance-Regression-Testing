# -*- coding: utf-8 -*-
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import sys
import random
import time

def genTab(nbr_elem):
	tab = []	
	for i in range(nbr_elem):
		tab.append(random.random())
	return tab

def sortTab(tab):
	restart = True
	while restart:
		restart = False
		for i in range(len(tab)-1):
			if tab[i] > tab[i+1]:
				temp = tab[i]
				tab[i] = tab[i+1]
				tab[i+1] = tab[i]
				restart = True				
				break
	return tab

def tabSorted(tab):
	for i in range(len(tab)-1):
		if tab[i] > tab[i+1]:
			return False
	return True

if __name__ == '__main__':
	start_gen = time.time()
	tab = genTab(5000);
	end_gen = time.time()
	print("Elapsed time to generate : %f Seconds" %  (end_gen - start_gen))

	start_sort = time.time()
	tab = sortTab(tab);
	end_sort = time.time()
	print("Elapsed time to sort : %f Seconds" %  (end_sort - start_sort))

	start_test = time.time()
	is_sorted = tabSorted(tab)
	end_test = time.time()
	print("Elapsed time to test : %f Seconds" %  (end_test - start_test))
